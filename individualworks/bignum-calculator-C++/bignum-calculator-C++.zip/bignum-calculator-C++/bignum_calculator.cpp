/*******************************************************************************************
	Name:		Abraham Chango

	Program:	A calculator that can add and multiply large numbers using stacks and basic
				C++ tasks

	Date:		04/23/2021

	Other info:	Requirements for the lab TO GET COMPETENCE were to:
				-You should receive no warning or error messages upon compilation with
				the exact following command
					-$ g++ -std=c++11 -Wall main.cpp bignum_calculator.cpp -o calc
				-Your implementation must not use any vectors or arrays
				-Your implementation must perform correct addition on any two positive
				integers that do and don't require carrying
				-Your implementation must perform correct multiplication on any two positive
				integers that do and don't require carrying

	TA Check:   N/A - did spend however substantial time, 8+ hours, in TA hours where Zach,
				Kayla and Alex (most time w/ Alex) would periodically help when necessary.
				They also had me test my own written functions one by one with my own test
				cases before moving on to the next, that way it was easier to pinpoint
				where my errors were coming from, as I progressed more and more
				into the assignment)

	Topics:		Covers non-negotiable topics - Linked Lists, Stacks, Queues

*******************************************************************************************/

#include "bignum_calculator.h"
#include <iostream>
#include <string>
#include <stack>

typedef bignum_calculator::bignum bignum;

bignum_calculator::bignum_calculator() {
	//nothing to do here
}

bignum_calculator::~bignum_calculator() {
	//nothing to do here
}
// converts the number in str to a bignum and stores it in num
void bignum_calculator::str_to_bignum(std::string str, bignum *num) {
	// initializes variable
	int number = 0;

	// loops through length of string
	for (long unsigned int i = 0; i < str.size(); i++) {

		// converts # of char to int
		number = str[i] - 48;

		// inserts new element 'number' at the top of stack of ints 'num' until done looping
		num->push(number);

	// print stack as test case
	/*for (int i = 0; i < num->size(); i++) {
		std::cout << num->top() << std::endl;
		num->pop();}*/
	}

}

// returns true if both bignums are the same, false otherwise
bool bignum_calculator::compare_bignum(bignum num_1, bignum num_2) {
	// check if size of both stacks are NOT the same
	if (num_1.size() != num_2.size()) {
		// compare_bignum test case
//		std::cout << "bignums not same" << std::endl;
		return false;
	}

	else {
    // loop through when stack is not empty
	    while (num_1.empty() == false) {

	    		// compare top elements of both stacks
	    		if (num_1.top() == num_2.top()) {

	    			// removes top elements of both stacks, all the way thr whole stacks
	    			num_1.pop();
	    			num_2.pop();
	    			// compare_bignum test case
//	    			std::cout << "bignums same" << std::endl;
	    			return true;
	    		}
	    		else {
	    			// compare_bignum test case
//	    			std::cout << "bignums not same" << std::endl;
	    			return false;
	    		}
	    	}
	    }

	// checks if both stacks are empty, then both bignums must be the same
	if (num_1.empty() == true && num_2.empty() == true) {
		// compare_bignum test case
//		std::cout << "bignums same" << std::endl;
		return true;
	}
}

//converts the bignum number to a string and returns the value of said string
std::string bignum_calculator::bignum_to_str(bignum num) {
	// initialize string
	std::string myString= "";

	// for leading zeros
	if (!num.empty()) {
		if (num.top() == 0) {
			return "0";
		}
	}

	// loops through stack when it is not empty (see piazza post on why to use while vs for loop for DD3)
	while (num.empty() == false) {

			// returns elements of stack as a string, incrementing thr whole stack
			myString = myString + std::to_string(num.top());

			// removes top element of stack, incrementing through whole stack
			num.pop();
			}
	// test case to see if value of said string is correct
//	std::cout << myString << std::endl;

	// returns the value of said string
	return myString;
}

// sums num_1 and num_2 and stores the result in sum
// TEST CASES ARE BY INPUT FILE
void bignum_calculator::add(bignum num_1, bignum num_2, bignum *sum) {
	// initialize var to store the carry generated
	int carry = 0;

	// initialize var that represents sum of top elements in stack
	int topSum = 0;

	// if both stacks num_1 and num_2 are empty, then new stack has to be empty
	if (num_1.empty() == true && num_2.empty() == true) {
		sum->empty() == true;
	}

	else {

		// loops through when both stacks num_1 and num_2 are not empty
		while (num_1.empty() == false && num_2.empty() == false) {

			// calculates sum of top elements in both stacks num_1 and num_2, including carry
			topSum = (carry + num_1.top() + num_2.top());

			// stores the carry, / 10 is for tens place value separation if carrying applied
			carry = topSum / 10;

			// inserts the sum at the top of the new stack, % 10 is for ones place value separation
			sum->push(topSum % 10);

			// removes top elements of both stacks num_1 and num_2, until stacks are empty
			num_1.pop();
			num_2.pop();

		}

		// loops through when stack num_1 is not empty (presuming stack 2 is empty)
		while (num_1.empty() == false) {

			// calculates sum of top elements in stack num_1, including carry
			topSum = (carry + num_1.top());

			// stores the carry, / 10 is for tens place value separation if carrying applied
			carry = topSum / 10;

			// inserts the sum at the top of the new stack, % 10 is for ones place value separation
			sum->push(topSum % 10);

			// removes top elements of stack num_1, until stacks are empty
			num_1.pop();

		}

		// loops through when stack num_2 is not empty (presuming stack 1 is empty)
		while (num_2.empty() == false) {

			// calculates sum of top elements in stack num_2, including carry
			topSum = (carry + num_2.top());

			// stores the carry, / 10 is for tens place value separation if carrying applied
			carry = topSum / 10;

			// inserts the sum at the top of the new stack, % 10 is for ones place value separation
			sum->push(topSum % 10);

			// removes top elements of stack num_2, until stacks are empty
			num_2.pop();

		}

		// if carry remains, inserts carry at top of new stack
		if (carry != 0) {
			// inserts carry at the top of the new stack
			sum->push(carry);

			// done required carrying
			carry = 0;
		}

	}

}

// multiplies num_1 and num_2 and stores the result in product
void bignum_calculator::multiply(bignum num_1, bignum num_2, bignum *product) {

	// initialize var to store the carry generated
	int carry = 0;

	// initialize var that represents the product of the top elements in stack
	int topProduct = 0;

	// initializes larger and smaller numbers
	bignum bigger;
	bignum smaller;


	// initialize counters
	int i, counter = 0;

	// if statement to confirm that larger number is on top and smaller number is on bottom, otherwise vice versa
	if (num_1.size() >= num_2.size()) {
		bigger = num_1;
		smaller = num_2;
//		std::cout << num_1.size() << std::endl;
	}

	else {
		bigger = num_2;
		smaller = num_1;
//		std::cout << num_1.size() << std::endl;
	}

	// loops through when stack smaller is not empty
	while (smaller.empty() == false) {
		// initializes new stack to represent the temp final products in the multiplication process
		bignum temp;
		bignum result;

		// intialize and reset bignum
		bignum temp2 = bigger;

		// inner loop that goes through when bigger stack is not empty
		while (temp2.empty() == false) {
//			std::cout << smaller.top() << "Smallertop" << std::endl;
//			std::cout << temp2.top() << "Smallertop" << std::endl;
			// calculates product of top elements in both stacks smaller and bigger, including carry
			topProduct = (smaller.top() * temp2.top()) + carry;
//			std::cout << topProduct << "topProd" << std::endl;

			// stores the carry, / 10 is for the tens place value separation if carrying applied
			carry = topProduct / 10;

			// stores first product , % 10 is for the ones place value separation
			temp.push(topProduct % 10);
//			std::cout << temp.top() << "tempTop" << std::endl;

			// removes top element of bigger stack, until stack is empty
			temp2.pop();

		}

		// if statement for if carry remains, inserts carry at top of new stack
		if (carry != 0) {
			// inserts carry at the top of the new stack
			temp.push(carry);

			// done required carrying
			carry = 0;
		}

		// initialize and reset bignum
		bignum temp3;
		// reversal loop
		while (!temp.empty()) {
			// insert top elements of temp stack into temp3
			temp3.push(temp.top());

			// removes top elements of temp stack, until stack is empty
			temp.pop();
		}
		// for loop to add zeroes to the 2nd # when necessary when adding products in the multiplication process
		for (i = 0; i < counter; i++) {
			// inserts 0 at top of the stack
			temp3.push(0);

		}

		// removes top element of smaller stack, until stack is empty
		smaller.pop();



		// calls add function to compute adding of products in multiplication process
//		std::cout << bignum_to_str(temp3) << 't' << std::endl;
		add(temp3, *product, &result);

		// initialize and reset bignum
		bignum temp4;
		// reversal loop
		while (!result.empty()) {
			// insert top elements of result into temp4
			temp4.push(result.top());

			// removes top elements of result stack, until stack is empty
			result.pop();
		}
//		std::cout << bignum_to_str(*product) << 'p' << std::endl;
//		std::cout << bignum_to_str(temp4) << 'r' << std::endl;

		// stores the product
		*product = temp4;

		// increments
		counter++;

	}

	// initialize and reset bignum
	bignum temp5;
	// reversal loop
	while (!product->empty()) {
		// insert top elements of product into temp5
		temp5.push(product->top());

		// removes top elements of product stack, until stack is empty
		product->pop();
		}

	// store product as temp5
	*product = temp5;

}

